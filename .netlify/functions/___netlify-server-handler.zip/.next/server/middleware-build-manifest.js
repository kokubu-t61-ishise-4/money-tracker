globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/bCBGkr-541SLN8yX3OtbB/_buildManifest.js",
    "static/bCBGkr-541SLN8yX3OtbB/_ssgManifest.js",
    "static/bCBGkr-541SLN8yX3OtbB/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ht900cau6_ur.js",
    "static/chunks/0fd~yqymdxc-w.js",
    "static/chunks/07lhk_q6pmm3r.js",
    "static/chunks/turbopack-16_yihokyncex.js"
  ]
};
